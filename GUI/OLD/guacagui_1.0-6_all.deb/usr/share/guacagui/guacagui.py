#!/usr/bin/env python3
"""
browser_app.py

A minimal cross‑platform tabbed web browser implemented with PyQt5. On
startup, the application reads a configuration file (`config.json`) from
the same directory to determine the URL to load in the initial tab. New
tabs can be opened by double‑clicking the tab bar or by clicking links
that request a new window (e.g. `target="_blank"`). Each tab is a
`QWebEngineView` with navigation controls (back, forward, reload, stop
and a URL bar) common to all tabs.

Usage:

    # install dependencies first
    pip install PyQt5 PyQtWebEngine
    
    # ensure config.json exists in the same directory as this script
    # and contains a JSON object with a "home_url" field, for example:
    # {"home_url": "https://www.example.com"}

    python3 browser_app.py

The application is designed to run on Windows, macOS and Linux, provided
PyQt5 and its WebEngine modules are available. QtWebEngine may require
additional system packages on some distributions.
"""

import json
import os
import sys
from functools import partial

from PyQt5.QtCore import QUrl, pyqtSlot, Qt, QEvent
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QStatusBar,
    QTabWidget,
    QToolBar,
    QAction,
    QLineEdit,
    QLabel,
)
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtGui import QKeyEvent, QGuiApplication, QClipboard


CONFIG_FILE = "config.json"


def read_config() -> dict:
    """Read configuration values from the local configuration file.

    Returns a dictionary with keys:

    - ``home_url``: The initial page to load. If missing or invalid, defaults to
      ``https://www.google.com``. A scheme is prepended if not provided.

    - ``macros``: A list of macro definitions. Each macro should be a
      dictionary with at least a ``name`` (the button label) and ``text`` (the
      keystrokes to send when clicked). If absent or invalid, an empty list is
      returned.
    """
    cfg = {
        "home_url": "https://www.google.com",
        "macros": [],
    }
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), CONFIG_FILE)
    if not os.path.exists(config_path):
        return cfg
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Load home_url
        url = data.get("home_url", cfg["home_url"])
        if isinstance(url, str):
            url = url.strip()
            if not url.startswith(("http://", "https://")):
                url = "https://" + url
            cfg["home_url"] = url
        # Load macros
        macros = data.get("macros", [])
        if isinstance(macros, list):
            # Validate each macro entry
            cleaned = []
            for entry in macros:
                if not isinstance(entry, dict):
                    continue
                name = entry.get("name") or entry.get("label") or entry.get("button")
                text = entry.get("text") or entry.get("macro")
                if isinstance(name, str) and isinstance(text, str):
                    cleaned.append({"name": name, "text": text})
            cfg["macros"] = cleaned
        return cfg
    except Exception:
        return cfg

def read_home_url() -> str:
    """Return the configured home URL with a scheme. Uses read_config() to parse the file."""
    cfg = read_config()
    return cfg.get("home_url", "https://www.google.com")

def read_macros() -> list:
    """Return a list of macro definitions from the configuration file."""
    cfg = read_config()
    return cfg.get("macros", [])


class BrowserTab(QWebEngineView):
    """A single browser tab which knows how to spawn new tabs when needed."""

    def __init__(self, main_window: "BrowserMainWindow", url: str | None = None) -> None:
        super().__init__()
        self.main_window = main_window
        # Initialise with provided URL or the home URL
        initial_url = url or read_home_url()
        self.setUrl(QUrl(initial_url))
        # When the URL changes or a page finishes loading, update the UI
        self.urlChanged.connect(self.on_url_changed)
        self.loadFinished.connect(self.on_load_finished)

        # When the page title changes, update the corresponding tab text and
        # propagate the title to the main window. This mirrors the behaviour
        # of mainstream browsers which display the page title as the tab name
        # once it becomes available. Without this, new tabs are labelled
        # generically (e.g. "New Tab") until the user switches to them.
        self.titleChanged.connect(self.on_title_changed)

    def createWindow(self, _type):  # type: ignore[override]
        """Overrides QWebEngineView.createWindow to open links in a new tab.

        When a link requests a new window (for example, via target="_blank"),
        Qt calls this method to provide a new view. Here we delegate to the
        main window to create a new tab and return the associated view.
        """
        new_tab = BrowserTab(self.main_window)
        self.main_window.add_browser_tab(new_tab, "New Tab")
        return new_tab

    @pyqtSlot(QUrl)
    def on_url_changed(self, url: QUrl) -> None:
        """Synchronise the URL bar when this tab's URL changes."""
        if self is self.main_window.current_browser():
            self.main_window.update_urlbar(url)

        # As soon as the URL changes (e.g. when a new tab is created and
        # navigates to its initial location), we update the tab's text to
        # reflect the destination. If the page title has not yet loaded,
        # fall back to showing the URL itself. The titleChanged signal will
        # override this once the title is available.
        idx = self.main_window.tabs.indexOf(self)
        if idx != -1:
            self.main_window.tabs.setTabText(idx, url.toString())

    @pyqtSlot(bool)
    def on_load_finished(self, _success: bool) -> None:
        """Update the window title when the page finishes loading."""
        # Once loading completes, update both the tab label and the
        # application window title. QWebEngineView will emit titleChanged
        # for the final title as well, but we ensure the tab text is set
        # immediately after the page finishes loading. If no title is
        # available, fall back to the URL string.
        title = self.page().title() or self.url().toString() or "Untitled"
        idx = self.main_window.tabs.indexOf(self)
        if idx != -1:
            self.main_window.tabs.setTabText(idx, title)
        if self is self.main_window.current_browser():
            self.main_window.update_title(title)

    @pyqtSlot(str)
    def on_title_changed(self, title: str) -> None:
        """Update the tab text and window title when the page title changes."""
        # When the page title updates (e.g. after navigation, or when
        # navigating to a link that specifies a title), reflect this in
        # the tab label. If the title is empty, use the URL instead.
        idx = self.main_window.tabs.indexOf(self)
        if idx != -1:
            tab_text = title.strip() if title.strip() else self.url().toString()
            self.main_window.tabs.setTabText(idx, tab_text)
        # If this tab is the current tab, update the main window title
        if self is self.main_window.current_browser():
            window_title = title.strip() if title.strip() else "Untitled"
            self.main_window.update_title(window_title)


class BrowserMainWindow(QMainWindow):
    """Main application window hosting a tabbed browser."""

    def __init__(self) -> None:
        super().__init__()
        # Set up the tab widget
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        # Allow tabs to be rearranged by dragging, similar to mainstream browsers.
        # Without this call, the tab order is fixed. Users often expect to be
        # able to drag tabs around to organise their workflow.
        self.tabs.setMovable(True)
        # Connect tab interactions
        self.tabs.tabBarDoubleClicked.connect(self.tab_open_doubleclick)
        self.tabs.tabCloseRequested.connect(self.close_current_tab)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        self.setCentralWidget(self.tabs)

        # Status bar to show page status (optional, can be extended)
        self.status = QStatusBar()
        self.setStatusBar(self.status)

        # Navigation toolbar
        navtb = QToolBar("Navigation")
        navtb.setMovable(False)
        self.addToolBar(navtb)

        # Back button
        back_btn = QAction("Back", self)
        back_btn.setStatusTip("Back to previous page")
        back_btn.triggered.connect(lambda: self.current_browser().back())
        navtb.addAction(back_btn)

        # Forward button
        next_btn = QAction("Forward", self)
        next_btn.setStatusTip("Forward to next page")
        next_btn.triggered.connect(lambda: self.current_browser().forward())
        navtb.addAction(next_btn)

        # Reload button
        reload_btn = QAction("Reload", self)
        reload_btn.setStatusTip("Reload current page")
        reload_btn.triggered.connect(lambda: self.current_browser().reload())
        navtb.addAction(reload_btn)

        # Home button
        home_btn = QAction("Home", self)
        home_btn.setStatusTip("Go to home page")
        home_btn.triggered.connect(self.navigate_home)
        navtb.addAction(home_btn)

        # Stop button
        stop_btn = QAction("Stop", self)
        stop_btn.setStatusTip("Stop loading current page")
        stop_btn.triggered.connect(lambda: self.current_browser().stop())
        navtb.addAction(stop_btn)

        # Load macros from configuration and create corresponding text boxes.
        self.macros = read_macros()
        if self.macros:
            # Separate navigation controls from the macro fields for clarity.
            navtb.addSeparator()
            for macro in self.macros:
                name = macro.get("name", "")
                text = macro.get("text", "")
                # Create a label to identify the text box (optional)
                if name:
                    lbl = QLabel(name + ":")
                    navtb.addWidget(lbl)
                # Create an editable text box pre-populated with the macro text
                box = QLineEdit()
                box.setText(text)
                # Set a reasonable fixed width so the toolbar does not expand indefinitely
                box.setFixedWidth(200)
                # Allow the user to edit the text if desired
                box.setReadOnly(False)
                # Add the box to the toolbar
                navtb.addWidget(box)

        # Create the first tab with the home URL
        home_url = read_home_url()
        first_tab = BrowserTab(self, url=home_url)
        self.add_browser_tab(first_tab, "Home")

        # Set the initial window title
        self.setWindowTitle("Simple Tabbed Browser")
        self.show()

    def current_browser(self) -> BrowserTab:
        """Return the currently active browser tab."""
        return self.tabs.currentWidget()  # type: ignore[return-value]

    def add_browser_tab(self, browser: BrowserTab, label: str = "New Tab") -> int:
        """Add a new browser tab and return its index."""
        i = self.tabs.addTab(browser, label)
        self.tabs.setCurrentIndex(i)
        return i

    # Slot: double clicking empty space on tab bar opens a new blank tab
    @pyqtSlot(int)
    def tab_open_doubleclick(self, index: int) -> None:
        if index == -1:
            new_tab = BrowserTab(self)
            self.add_browser_tab(new_tab, "New Tab")

    # Slot: update UI when the current tab changes
    @pyqtSlot(int)
    def current_tab_changed(self, index: int) -> None:
        browser = self.current_browser()
        if not isinstance(browser, BrowserTab):
            return
        url = browser.url()
        self.update_urlbar(url)
        title = browser.page().title() or "Untitled"
        self.update_title(title)

    # Slot: close the selected tab
    @pyqtSlot(int)
    def close_current_tab(self, index: int) -> None:
        if self.tabs.count() < 2:
            return
        self.tabs.removeTab(index)

    def update_title(self, title: str) -> None:
        """Set the window title to reflect the current page title."""
        self.setWindowTitle(title)

    def update_urlbar(self, qurl: QUrl) -> None:
        """Update the URL bar with the given URL.

        This method is retained for backward compatibility. If a URL input
        field is present, it will be updated; otherwise, this method
        performs no action.
        """
        # If the URL bar exists, update it; otherwise ignore.
        urlbar = getattr(self, "urlbar", None)
        if isinstance(urlbar, QLineEdit):
            urlbar.setText(qurl.toString())
            urlbar.setCursorPosition(0)

    # Navigation actions
    def navigate_home(self) -> None:
        """Navigate the current tab to the configured home URL."""
        url = read_home_url()
        self.current_browser().setUrl(QUrl(url))

    def navigate_to_url(self) -> None:
        """Navigate the current tab to the URL entered in the URL bar.

        If the URL bar has been removed (for example, when using this
        application in a fixed-location kiosk mode), this method does nothing.
        """
        urlbar = getattr(self, "urlbar", None)
        if not isinstance(urlbar, QLineEdit):
            return
        url_text = urlbar.text().strip()
        # Provide a default scheme if missing
        if url_text and not url_text.startswith(("http://", "https://")):
            url_text = "http://" + url_text
        self.current_browser().setUrl(QUrl(url_text))



def main() -> None:
    """Entry point: create the application and run the main loop."""
    app = QApplication(sys.argv)
    window = BrowserMainWindow()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()