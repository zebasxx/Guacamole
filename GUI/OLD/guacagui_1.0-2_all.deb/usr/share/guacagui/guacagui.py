#!/usr/bin/env python3
import json
import sys
from pathlib import Path

from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QStatusBar,
    QToolBar, QAction, QLineEdit
)
from PyQt5.QtWebEngineWidgets import QWebEngineView

CONFIG_NAME = "config.json"

def load_home_url(app_dir: Path) -> str:
    cfg = app_dir / CONFIG_NAME
    default = "https://www.google.com"
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
        url = (data.get("home_url") or "").strip()
        return url if url else default
    except Exception:
        return default

class BrowserView(QWebEngineView):
    def __init__(self, main_window: "MainWindow"):
        super().__init__()
        self._mw = main_window
    # open new-window requests (e.g. target=_blank) in a new tab
    def createWindow(self, _type):
        return self._mw.add_new_tab(return_view_only=True)

class MainWindow(QMainWindow):
    def __init__(self, app_dir: Path):
        super().__init__()
        self.setWindowTitle("Guacagui")
        self.app_dir = app_dir
        self.home_url = load_home_url(app_dir)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.tabBarDoubleClicked.connect(self.open_blank_tab)
        self.setCentralWidget(self.tabs)

        self.status = QStatusBar()
        self.setStatusBar(self.status)

        navtb = QToolBar("Navigation")
        self.addToolBar(navtb)

        back_btn = QAction("Back", self)
        back_btn.setStatusTip("Back to previous page")
        back_btn.triggered.connect(lambda: self.current_view() and self.current_view().back())
        navtb.addAction(back_btn)

        next_btn = QAction("Forward", self)
        next_btn.setStatusTip("Forward to next page")
        next_btn.triggered.connect(lambda: self.current_view() and self.current_view().forward())
        navtb.addAction(next_btn)

        reload_btn = QAction("Reload", self)
        reload_btn.setStatusTip("Reload page")
        reload_btn.triggered.connect(lambda: self.current_view() and self.current_view().reload())
        navtb.addAction(reload_btn)

        home_btn = QAction("Home", self)
        home_btn.setStatusTip("Go home")
        home_btn.triggered.connect(self.navigate_home)
        navtb.addAction(home_btn)

        navtb.addSeparator()

        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)
        navtb.addWidget(self.urlbar)

        stop_btn = QAction("Stop", self)
        stop_btn.setStatusTip("Stop loading current page")
        stop_btn.triggered.connect(lambda: self.current_view() and self.current_view().stop())
        navtb.addAction(stop_btn)

        # first tab
        self.add_new_tab(QUrl(self.home_url), "Home")

    def current_view(self):
        w = self.tabs.currentWidget()
        return w if isinstance(w, BrowserView) else None

    def open_blank_tab(self, i: int):
        if i == -1:
            self.add_new_tab()

    def close_tab(self, i: int):
        if self.tabs.count() > 1:
            self.tabs.removeTab(i)

    def add_new_tab(self, qurl: QUrl=None, label: str="New Tab", return_view_only: bool=False):
        view = BrowserView(self)
        if qurl is not None:
            view.setUrl(qurl)
        view.urlChanged.connect(lambda q, v=view: self._update_urlbar(q, v))
        view.loadFinished.connect(lambda _ : self._update_tab_title(view))
        idx = self.tabs.addTab(view, label)
        if not return_view_only:
            self.tabs.setCurrentIndex(idx)
        return view

    def _update_tab_title(self, view: BrowserView):
        i = self.tabs.indexOf(view)
        if i != -1:
            self.tabs.setTabText(i, view.page().title() or "Tab")

    def _update_urlbar(self, q: QUrl, view: BrowserView):
        if view is self.current_view():
            self.urlbar.setText(q.toString())
            self.urlbar.setCursorPosition(0)

    def navigate_home(self):
        v = self.current_view()
        if v:
            v.setUrl(QUrl(self.home_url))

    def navigate_to_url(self):
        text = self.urlbar.text().strip()
        if not text:
            return
        q = QUrl(text)
        if q.scheme() == "":
            q.setScheme("http")
        v = self.current_view()
        if v:
            v.setUrl(q)

def main():
    app = QApplication(sys.argv)
    app_dir = Path(__file__).resolve().parent
    w = MainWindow(app_dir)
    w.resize(1200, 800)
    w.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
